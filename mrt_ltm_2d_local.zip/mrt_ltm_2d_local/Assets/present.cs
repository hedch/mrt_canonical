﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class present : MonoBehaviour {

    protected const int obj_num = 3;
    protected const int ang_num = 7;
    protected const int rep_num = 1;

    protected float ini_ang = 0f;
    protected float intv_ang = 45f;
    const int num_total = obj_num * ang_num * rep_num;
    protected int[][] _tag = new int[num_total][];

    protected const float s1 = 2f;
    protected const float isi = 1f + s1;

    public float _timer = 0f;

    public GameObject reference;
    protected GameObject a;
    protected GameObject b;
    protected GameObject c;
    public int index = 0;

    protected Vector3 vanish_pos = new Vector3(100f, 100f, 45f);

    bool permit = true;
    bool adjust = false;
    public int adj_obj = 0;
    Vector3 adj_pos = new Vector3(0, 60, 0);
    // Use this for initialization
    void Start () {
    a = GameObject.Find("O11");
    b = GameObject.Find("O21");
    c = GameObject.Find("O31");
    ini_present_seq();
    }
	
	// Update is called once per frame
	void Update () {
        _timer += Time.deltaTime;
        if (adjust) {
            switch (adj_obj) {
                case 1:
                    a.transform.position = adj_pos;
                    b.transform.position = vanish_pos;
                    c.transform.position = vanish_pos;
                    break;

                case 2:
                    b.transform.position = adj_pos;
                    a.transform.position = vanish_pos;
                    c.transform.position = vanish_pos;
                    break;

                case 3:
                    c.transform.position = adj_pos;
                    b.transform.position = vanish_pos;
                    a.transform.position = vanish_pos;
                    break;
            }
        }

        if (_timer > isi && permit) {
            _timer = 0;
            if (index == num_total)
            {
                permit = false;
            }
            else {
                StartCoroutine(pres_target());
                
            }
        }

    }
    IEnumerator pres_target()
    {
        destroy_target();
        yield return new WaitForSeconds(isi-s1);
        create_target();
    }

    void create_target()
    {

        reference.transform.eulerAngles = new Vector3(0, 0, 0);
        reference.transform.Rotate(new Vector3(0, ini_ang + _tag[index][1] * intv_ang, 0), Space.World);
        switch (_tag[index][0])
        {
            case 0:
                a.transform.position = adj_pos;
                a.transform.localRotation = reference.transform.localRotation;
                break;
            case 1:
                b.transform.position = adj_pos;
                b.transform.localRotation = reference.transform.localRotation;
                break;
            case 2:
                c.transform.position = adj_pos;
                c.transform.localRotation = reference.transform.localRotation;
                break;
        }
        index++;
    }
    void destroy_target() {
        a.transform.position = vanish_pos;
        b.transform.position = vanish_pos;
        c.transform.position = vanish_pos;
    }

    void ini_present_seq()
    {

        for (int i = 0; i < num_total; i++)
        {
            _tag[i] = new int[] { i / (rep_num * ang_num ) % obj_num, i / rep_num % ang_num, i % rep_num };
        }
        Random.InitState(20);
        for (int i = num_total - 1; i > 0; i--)
        {
            int p = Random.Range(0, i);
            int[] temp = _tag[p];
            _tag[p] = _tag[i];
            _tag[i] = temp;
        }


    }
}
