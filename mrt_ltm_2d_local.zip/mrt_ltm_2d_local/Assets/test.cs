﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour {
    public string result_title = "sj";
    protected const int obj_num = 3;
    protected const int ang_num = 9;
    protected const int rep_num = 1;
    protected const int hand_num = 2;
    public int wrong = 0;
    public float perc_wrong = 0;
    public int seed = 10;
  
    protected float ini_ang = 0f;
    protected float intv_ang = 45f;
    public const int num_total = obj_num * ang_num * rep_num * hand_num + 6;
    protected int[][] _tag = new int[num_total][];

    public GameObject reference;
    protected GameObject sti;
    protected GameObject sti_on;
    protected GameObject a;
    protected GameObject b;
    protected GameObject c;

    public float _timer = 0f;
    protected float time_begin = 0f;
    protected bool receiver = true;
    public int index = 0;


    protected float[] rt = new float[num_total + 1];
    protected string resp = "";
    protected float[] shape = new float[num_total];
    protected float[] cor_ans = new float[num_total];
    protected float[] angle = new float[num_total];

    protected float delay = 1f;
    protected Vector3 pres_pos = new Vector3(0f, 0f, -60f);
    protected Vector3 vanish_pos = new Vector3(100f, 100f, 45f);

    private AudioSource cue;

    // Use this for initialization
    void Start () {
        cue = gameObject.GetComponent<AudioSource>();
        a = GameObject.Find("O1");
        b = GameObject.Find("O2");
        c = GameObject.Find("O3");
        ini_present_seq();
        sti = (GameObject)Resources.Load("start");
        sti_on = Instantiate(sti, new Vector3(-6.0f, -8.0f, -35f), Quaternion.Euler(new Vector3(0.0f, 0.0f, 0.0f))) as GameObject;
    }
	
	// Update is called once per frame
	void Update () {
        transform.rotation = Quaternion.Euler(new Vector3(90f, 0, 0));
        _timer += Time.deltaTime;
        if ((Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1)) && receiver) {
            receiver = false;
            rt[index] = _timer - time_begin;
            perc_wrong = wrong / (index + 1);
            foreach (KeyCode keyCode in System.Enum.GetValues(typeof(KeyCode)))
            {
                if (Input.GetKeyDown(keyCode))
                {
                    resp += keyCode.ToString();
                    if (index > 0) {
                        if (int.Parse(resp.Substring(resp.Length - 1, 1)) != cor_ans[index - 1])
                        {
                            cue.Play();
                            wrong++;
                          
                        }
                    }
                }
            }

            destroy_target();

            if (index == num_total)
            {
                finish();
            }
            else {
                StartCoroutine(pres_target());
                time_begin = _timer;
                receiver = true;
            }
        }
    }

    IEnumerator pres_target()
    {
        yield return new WaitForSeconds(delay);
        create_target();
    }
    void finish()
    {

        sti = (GameObject)Resources.Load("finish");

        sti_on = Instantiate(sti, new Vector3(-2.0f, 0.0f, -40f), Quaternion.Euler(new Vector3(0.0f, 0.0f, 0.0f))) as GameObject;


        string _rt = "reaction time: " + floatListToString(rt) + "\r\n";
        string _resp = "response: " + resp + "\r\n";
        string _shape = "shape: " + floatListToString(shape) + "\r\n";
        string _cor_ans = "correct answer: " + floatListToString(cor_ans) + "\r\n";
        string _angle = "angle: " + floatListToString(angle) + "\r\n";

        string result = _rt + _resp + _shape + _cor_ans + _angle;
        string file_name = result_title;

        data_file.Create_file(Application.dataPath, file_name, result);
    }
    void destroy_target()
    {
        if (index == 0)
        {
            Destroy(sti_on);
        }
        a.transform.position = vanish_pos;
        b.transform.position = vanish_pos;
        c.transform.position = vanish_pos;
    }
    void create_target()
    {
        reference.transform.eulerAngles = new Vector3(0, 0, 0);
        switch (_tag[index][2])
        {
            case 0:
                reference.transform.Rotate(new Vector3(90, 0, 0), Space.World);
                break;
            case 1:
                reference.transform.Rotate(new Vector3(90, 180, 0), Space.World);
                break;

        }
        //Debug.Log(_tag[index][1]);
        switch (_tag[index][0])
        {
            case 0:
                a.transform.position = pres_pos;
                a.transform.localRotation = reference.transform.localRotation;
                a.transform.Rotate(Vector3.up * (ini_ang + _tag[index][1] * intv_ang));
                break;
            case 1:
                b.transform.position = pres_pos;
                b.transform.localRotation = reference.transform.localRotation;
                b.transform.Rotate(Vector3.up * (ini_ang + _tag[index][1] * intv_ang));
                break;
            case 2:
                c.transform.position = pres_pos;
                c.transform.localRotation = reference.transform.localRotation;
                c.transform.Rotate(Vector3.up * (ini_ang + _tag[index][1] * intv_ang));
                break;
        }

        shape[index] = _tag[index][0];
        cor_ans[index] = _tag[index][2];
        angle[index] = _tag[index][1] * intv_ang + ini_ang;
        index++;
    }

    void ini_present_seq()
    {

        for (int i = 0; i < num_total-6; i++)
        {
            _tag[i] = new int[] { i / (rep_num  * ang_num * hand_num) % obj_num, i / (rep_num * hand_num) % ang_num, i / rep_num  % hand_num, i % rep_num };

        }

        for (int i = 0; i < 6; i++) {
            _tag[num_total-i-1] = new int[] { i % 3, 4, i / 3, 0 };
        }

            Random.InitState(seed);
        for (int i = num_total - 1; i > 0; i--)
        {
            int p = Random.Range(0, i);
            int[] temp = _tag[p];
            _tag[p] = _tag[i];
            _tag[i] = temp;
        }


    }
    string floatListToString(float[] list)
    {
        string str = "";
        foreach (float n in list)
            str += n + "--";

        return str;
    }
}
