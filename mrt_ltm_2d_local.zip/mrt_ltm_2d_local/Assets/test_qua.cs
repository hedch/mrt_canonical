﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test_qua : MonoBehaviour {
    public float[] qua = new float[] { 0, 0, 0, 0 };
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.Rotate(Vector3.up *1);
        qua[0] = transform.rotation.x;
        qua[1] = transform.rotation.y;
        qua[2] = transform.rotation.z;
        qua[3] = transform.rotation.w;
    }
}
